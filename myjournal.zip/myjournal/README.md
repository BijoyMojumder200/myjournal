# MyJournal

*MyJournal* is a personal journal web app where users can register, log in, write journal entries, edit or delete them, and view all their entries in a list. The project is built with Python (Flask) and uses SQLite for data storage.

## Features

- User registration and login
- Passwords securely hashed
- Add, edit, and delete journal entries
- View all entries on a homepage
- SQLite database backend

## How to run

1. Run flask run from the terminal
2. Open the link in the browser
3. Register a new account
4. Start journaling!

## Folder Structure

myjournal/ ├── app.py ├── journal.db ├── requirements.txt ├── README.md └── templates/ ├── login.html ├── register.html ├── index.html ├── add.html └── edit.html

## Author

Bijoy Mojumder
CS50 Final Project – 2025
