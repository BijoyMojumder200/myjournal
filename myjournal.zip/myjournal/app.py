from flask import Flask, render_template, request, redirect, session
from flask_session import Session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3

app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Database setup
def get_db():
    conn = sqlite3.connect("journal.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    if "user_id" not in session:
        return redirect("/login")
    db = get_db()
    user = db.execute("SELECT username FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    if user is None:
        return redirect("/login")
    entries = db.execute("SELECT * FROM entries WHERE user_id = ? ORDER BY created_at DESC", (session["user_id"],)).fetchall()
    return render_template("index.html", entries=entries, username=user["username"])

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        confirm = request.form.get("confirmation")

        if not username or not password or password != confirm:
            return "Invalid input", 400

        hash_pw = generate_password_hash(password)
        db = get_db()
        try:
            db.execute("INSERT INTO users (username, hash) VALUES (?, ?)", (username, hash_pw))
            db.commit()
        except:
            return "Username already exists", 400

        return redirect("/login")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    session.clear()
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

        if user is None or not check_password_hash(user["hash"], password):
            return "Invalid credentials", 400

        session["user_id"] = user["id"]
        return redirect("/")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

@app.route("/delete/<int:entry_id>", methods=["POST"])
def delete(entry_id):
    if "user_id" not in session:
        return redirect("/login")

    db = get_db()
    db.execute("DELETE FROM entries WHERE id = ? AND user_id = ?", (entry_id, session["user_id"]))
    db.commit()
    return redirect("/")


@app.route("/add", methods=["GET", "POST"])
def add():
    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":
        content = request.form.get("content")

        if not content:
            return "Entry cannot be empty", 400

        db = get_db()
        db.execute(
            "INSERT INTO entries (user_id, content) VALUES (?, ?)",
            (session["user_id"], content)
        )
        db.commit()
        return redirect("/")

    return render_template("add.html")


@app.route("/edit/<int:entry_id>", methods=["GET", "POST"])
def edit(entry_id):
    if "user_id" not in session:
        return redirect("/login")

    db = get_db()

    if request.method == "POST":
        new_content = request.form.get("content")
        if not new_content:
            return "Content cannot be empty", 400

        db.execute(
            "UPDATE entries SET content = ? WHERE id = ? AND user_id = ?",
            (new_content, entry_id, session["user_id"])
        )
        db.commit()
        return redirect("/")

    entry = db.execute(
        "SELECT * FROM entries WHERE id = ? AND user_id = ?",
        (entry_id, session["user_id"])
    ).fetchone()

    if entry is None:
        return "Entry not found", 404

    return render_template("edit.html", entry=entry)

# Run the app
if __name__ == "__main__":
    app.run(debug=True)

